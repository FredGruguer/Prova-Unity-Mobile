using UnityEngine;

public class ControllerCharacter : MonoBehaviour
{
    [Header("Player Animation")]
    public Animator animatorplayer;

    public float walkSpeed = 3.0f;
    private Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {

        float movX = Input.GetAxis("Horizontal");
        float movY = Input.GetAxis("Vertical");
        

        rb.linearVelocity = new Vector2(movX * walkSpeed, movY * walkSpeed);

        UpdateAnimation(movX, movY);

    }

    void UpdateAnimation(float movX, float movY)
    {
        bool Right = movX > 0;
        bool Left = movX < 0;
        bool Up = movX > 0;
        bool Down = movY < 0;

        animatorplayer.SetBool("WalkRight", Right);
        animatorplayer.SetBool("WalkLeft", Left);
        animatorplayer.SetBool("WalkUp", Up);
        animatorplayer.SetBool("WalkDown", Down);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
