using UnityEngine;

public class ControllerCharacter : MonoBehaviour
{
    [Header("Player Animation")]
    public Animator animatorplayer;

    public float walkSpeed = 3.0f;
    private Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {

        float movX = Input.GetAxis("Horizontal");
        float movY = Input.GetAxis("Vertical");
        

        rb.linearVelocity = new Vector2(movX * walkSpeed, movY * walkSpeed);

        UpdateAnimation(movX, movY);

    }

    void UpdateAnimation(float movX, float movY)
    {
        bool walkRight = movX > 0;
        bool walkLeft = movX < 0;
        bool walkUp = movX > 0;
        bool walkDown = movY < 0;

        animatorplayer.SetBool("WalkRight", walkRight);
        animatorplayer.SetBool("WalkLeft", walkLeft);
        animatorplayer.SetBool("WalkUp", walkUp);
        animatorplayer.SetBool("WalkDown", walkDown);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
